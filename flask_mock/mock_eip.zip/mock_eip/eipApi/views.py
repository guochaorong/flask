"""
test
"""
import sys
sys.path.append(".")

import json
import time

import pprint
from pprint import pprint as pp
import StringIO
import traceback
import string

from api import keystone_api
from api import neutron_vpc_api
from common import config
from common import localcmd
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from eipApi.models import Eip
from eipApi.models import FipPort
from eipApi.serializers import EipSerializer
from eipApi.serializers import FipPortSerializer
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser

class JSONResponse(HttpResponse):
    """
    An HttpResponse that renders its content into JSON.
    """
    def __init__(self, data, **kwargs):
        content = JSONRenderer().render(data)
        kwargs['content_type'] = 'application/json'
        super(JSONResponse, self).__init__(content, **kwargs)

CONF = config.CommonConf()
user_name = CONF.get_conf('vpn_user_name')                                    
password = CONF.get_conf('vpn_user_password')                                 
tenant = CONF.get_conf('vpn_tenant_id')                                       
domain_name = CONF.get_conf('vpn_domain_name')                                
domain_id = CONF.get_conf('vpn_domain_id')                                    
keystone = keystone_api.Keystone(user_name, password,                    
                     tenant, domain_name, domain_id, True)  

neutron_api = neutron_vpc_api.NeutronVpcApi('root', keystone=keystone)
all_nets = neutron_api.listNetwork()
for i in all_nets:
    if i['name'] == 'pnet':
        pnet_id = i['id']
        break
for i in Eip.objects.filter():
    i.delete()


def _eip_list(eip):
    eips = Eip.objects.filter(eip=eip)
    serializer = EipSerializer(eips, many=True)
    data = serializer.data
    return data[0] if len(data) > 0 else None 


@csrf_exempt
def eip_create_query(request):
    """test"""
    req = JSONParser().parse(request)
    if request.method == 'POST':
        bandwidthInMbps = req.get('bandwidthInMbps', 1)
        return _eip_create(bandwidthInMbps)
    if request.method == 'PUT':
        return _eip_query(req)
    return JSONResponse('operate error', status=400)


def _eip_create(bandwidthInMbps):
    fips = neutron_api.createFloatingip({"floating_network_id": pnet_id})
    id = fips['id']
    eip = fips['floating_ip_address']
    pnet = fips['floating_network_id']
    eips = {
        "eips": [
            {
                "eip": eip,
                "bandwidthInMbps": bandwidthInMbps,
                "status": "available",
            },
        ]
    }

    sdata = {
        "id": id,
        "eip": eip,
        "pnetIp": pnet,
        "instanceType": "GUESS",
        "instanceId": "GUESS",
        "status": "available",
        "bandwidthInMbps": bandwidthInMbps,
    }
    serializer = EipSerializer(data=sdata)
    if serializer.is_valid():
        serializer.save()
    return JSONResponse(eips, status=200)


def _eip_query(req):
    instance_type = req.get('instanceType', '')
    instance_id = req.get('instanceId', '')
    instance_ids = req.get('instanceIdList', list())
    if instance_id == '':
        instance_id = instance_ids[0]
    eips = Eip.objects.filter(instanceType=instance_type, instanceId=instance_id)
    if len(eips):
        bindList = []
        for i in eips:
            eipdict = {}
            eipdict["eip"] = i.eip
            eipdict["instanceId"] = i.instanceId
            eipdict["bind"] = True
            eipdict["status"] = i.status
            bindList.append(eipdict)
        bindInstanceList = {
            "bindInstanceList": bindList
        }
    else:
        bindInstanceList = {
            "bindInstanceList": [
                {
                    "instanceId": instance_id,
                    "bind": False,
                },
            ]
        }
    return JSONResponse(bindInstanceList, status=200)


@csrf_exempt
def eip_operate(request, eip_addr):
    """test"""
    if request.method == 'PUT':
        operate = request.GET.get("action", "")
        if operate == 'bind':
            import datetime
            print datetime.datetime.now(), 'bind  begin ==================='
            data = JSONParser().parse(request)
            instance_id = data['instanceId']
            instance_type = data['instanceType']
            pnet_ip = data['pnetIp']
            if _eip_bind(eip_addr, instance_type, instance_id, pnet_ip):
                print datetime.datetime.now(), 'bind return ===============' 
                return JSONResponse(None, status=200)

        if operate == 'unbind':
            if _eip_unbind(eip_addr):
                return JSONResponse(None, status=200)

        if operate == 'update':
            data = JSONParser().parse(request)
            bps =  data.get('bandwidthInMbps', None)
            if bps and _eip_update(eip_addr, bps):
                return JSONResponse(None, status=200)

    elif request.method == 'GET':
        return JSONResponse(_eip_list(eip_addr), status=200)

    elif request.method == 'DELETE':
        if _eip_delete(eip_addr):
            return JSONResponse(None, status=200)

    print datetime.datetime.now(), 'return error ===================' 
    return JSONResponse('operate error', status=400)


def _eip_unbind(ip):
    fip = neutron_api.listFloatingip(filters={"floating_ip_address": ip})
    if len(fip) == 0:
        return False

    fip_id = fip[0]['id']
    eip = fip[0]['floating_ip_address']
    pnet = fip[0]['floating_network_id']

    neutron_api.disassociateFloatingip(fip_id)

    data = {
        "id": fip_id,
        "eip": eip,
        "pnetIp": pnet,
        "instanceType": "GUESS",
        "instanceId": "GUESS",
        "status": "available",
        "bandwidthInMbps": 1,
    }
    serializer = EipSerializer(data=data)
    eip = Eip.objects.filter(id=fip_id)
    if eip:
        eip.update(eip=ip, status="available", pnetIp="",
                   instanceId="", instanceType="")
    else:
        serializer = EipSerializer(data=data)
        if serializer.is_valid():
            serializer.save()

    return True


def _get_port_id_from_floatingip(floatingip):
    #fip = FipPort.objects.filter(fip=floatingip)
    #if fip:
    #    return fip[0].port_id
    fip_vm = neutron_api.listFloatingip(filters={"floating_ip_address": floatingip})
    if len(fip_vm) == 0:
        return ""
    fip_port_id = fip_vm[0]["port_id"]
    data = {
        "fip": floatingip,
        "port_id": fip_port_id
    }
    serializer = FipPortSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return fip_port_id
    return ""


def _get_port_id_from_instance(instance_id):
    _mysql_host = CONF.get_conf("mysql_host", "localhost")
    _mysql_user = CONF.get_conf("mysql_user", "bcc")
    _mysql_pass = CONF.get_conf("mysql_pass", "bcc")
    _mysql_port = int(CONF.get_conf("mysql_port", 3306))
    try:
        if instance_id[0:3] == 'vpn':
            #The VPN may not exist in db before active
            _mysql = CONF.get_conf("vpn_db", "bce_vpn_master")
            sql = "select vm_id from vpn_vm_gateway where status!='deleted' \
                and state='primary' and vpn_id='%s';" % instance_id
            cmd = 'mysql -u%s -p%s -h%s -P%s -B %s -e "%s"' \
                % (_mysql_user, _mysql_pass, _mysql_host, _mysql_port,
                _mysql, sql)
            lc = localcmd.LocalCommand()
            instance_id = lc.exeCommand(cmd)[1]
            instance_id = instance_id.split('\n')[1]
        if instance_id[0:3] == 'nat':
            _mysql = CONF.get_conf("nat_db", "bce_network_gateways")
            sql = "select id from nat_gateway_instances where state = 'primary' \
                and nat_gateway_id = (select id from nat_gateways \
                where short_id = '%s'); " % instance_id
            cmd = 'mysql -u%s -p%s -h%s -P%s -B %s -e "%s"' \
                % (_mysql_user, _mysql_pass, _mysql_host, _mysql_port,
                _mysql, sql)
            lc = localcmd.LocalCommand()
            instance_id = lc.exeCommand(cmd)[1]
            instance_id = instance_id.split('\n')[1]

        print 'Get primary instance_id %s' % instance_id
        return neutron_api.listPort(filters={"device_id":instance_id})[0]['id']
    except Exception as e:
        return None

def _get_free_fix_ip(port_id):
    ips = neutron_api.showPort(port_id)['fixed_ips']
    fixip_list = []
    for i in ips:
        fixip_list.append(i['ip_address'])
    ips = neutron_api.listFloatingip(filters={"port_id": port_id})
    for i in ips:
        fixip_list.pop(fixip_list.index(i['fixed_ip_address']))
    return fixip_list[0]

def _eip_bind(ip, instance_type, instance_id, pnet_ip):
    fip = neutron_api.listFloatingip(filters={"floating_ip_address": ip})

    if len(fip) == 0:
        return False

    fip_id = fip[0]['id']
    
    timeout = 3
    port_id = None
    while not port_id and timeout:
        port_id = _get_port_id_from_floatingip(pnet_ip)
        timeout = timeout - 1
    if not port_id:
        port_id = _get_port_id_from_instance(instance_id)
    if not port_id:
        return False
    fip_vm = neutron_api.listFloatingip(filters={"port_id": port_id})
    
    for i in fip_vm:
        if i["floating_ip_address"] == pnet_ip:
            neutron_api.disassociateFloatingip(i['id'])
            time.sleep(1)

    neutron_api.associateFloatingip(fip_id, port_id, _get_free_fix_ip(port_id))

    data = {
        "id": fip_id,
        "eip": ip,
        "pnetIp": pnet_ip,
        "instanceType": instance_type,
        "instanceId": instance_id,
        "status": "binded",
        "bandwidthInMbps": 1,
    }
    serializer = EipSerializer(data=data)
    eip = Eip.objects.filter(id=fip_id)
    if eip:
        eip.update(eip=ip, status="binded", pnetIp=pnet_ip,
                   instanceId=instance_id, instanceType=instance_type)
    else:
        serializer = EipSerializer(data=data)
        if serializer.is_valid():
            serializer.save()

    return True


def _eip_update(ip, bps):
    fip = neutron_api.listFloatingip(filters={"floating_ip_address": ip})

    if len(fip) == 0:
        return False

    fip_id = fip[0]['id']

    eip = Eip.objects.get(id=fip_id)
    eip.bandwidthInMbps = bps
    eip.save()

    return True


def _eip_delete(ip):
    fip = neutron_api.listFloatingip(filters={"floating_ip_address": ip})

    if len(fip) == 0:
        return False

    fip_id = fip[0]['id']

    eip = Eip.objects.get(id=fip_id)
    eip.delete()

    neutron_api.deleteFloatingip(fip_id)

    return True
