"""
test
"""
from __future__ import unicode_literals

from django.db import models

class Eip(models.Model):
    """test"""
    id = models.CharField(max_length=100, primary_key=True)
    instanceType = models.CharField(max_length=100)
    instanceId = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    eip = models.CharField(max_length=100)
    pnetIp = models.CharField(max_length=100)
    bandwidthInMbps = models.IntegerField()


class FipPort(models.Model):
    """test"""
    fip = models.CharField(max_length=100, primary_key=True)
    port_id = models.CharField(max_length=100)
