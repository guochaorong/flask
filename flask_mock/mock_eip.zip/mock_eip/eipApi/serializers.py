"""
test
"""
from rest_framework import serializers
from eipApi.models import Eip
from eipApi.models import FipPort

class EipSerializer(serializers.ModelSerializer):
    """test"""
    class Meta:
        model = Eip
        fields = ('id', 'eip', 'status', 'bandwidthInMbps', 
                  'instanceType', 'instanceId', 'pnetIp')


class FipPortSerializer(serializers.ModelSerializer):
    """test"""
    class Meta:
        model = FipPort
        fields = ('fip', 'port_id')
