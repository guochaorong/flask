#!/bin/bash
vmid=$1
ip=$2
pnet=$3
curl -X PUT 127.0.0.1:8086/json-api/v2/eip/$ip?action=unbind -d '{"instanceId":"'$vmid'","instanceType":"BCC","pnetIp":"'$pnet'"}'
