#!/bin/bash
curl -X GET 127.0.0.1:8086/json-api/v2/eip/$1
#curl -X PUT 127.0.0.1:8086/json-api/v2/eip?action=query -d '{"instanceIdList":[""],"instanceType":"NAT"}'
