#!/bin/bash
curl -X PUT 127.0.0.1:8086/json-api/v2/eip?action=query -d '{"instanceIdList":["'$1'"],"instanceType":"NAT"}'
