#!/bin/bash
curl -X POST 127.0.0.1:8086/json-api/v2/eip?action=create -d '{"bandwidthInMbps": 100}'
