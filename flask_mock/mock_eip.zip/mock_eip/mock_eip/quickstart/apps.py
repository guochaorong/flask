"""
test
"""
from __future__ import unicode_literals

from django.apps import AppConfig


class QuickstartConfig(AppConfig):
    """test"""
    name = 'quickstart'
